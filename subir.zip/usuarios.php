<?php
include 'bd/bd.php';
echo "<title>Control de Usuarios</title>";
include "controllers/c_usuarios.php";

// MOD MENU
include "controllers/c_mod.php";
footer();


?>