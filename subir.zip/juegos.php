<?php
include 'bd/bd.php';
include "controllers/c_usuarios.php";
//include "controllers/c_plataformas.php";

include "controllers/c_juegos.php";

footer();
?>